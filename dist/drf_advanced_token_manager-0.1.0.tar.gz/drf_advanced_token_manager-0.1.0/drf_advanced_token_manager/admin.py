from django.contrib import admin
from drf_advanced_token_manager.models import UserUIKeyLock

admin.site.register(UserUIKeyLock)