from django.apps import AppConfig


class DrfAdvancedTokenManagerConfig(AppConfig):
    name = 'drf_advanced_token_manager'
